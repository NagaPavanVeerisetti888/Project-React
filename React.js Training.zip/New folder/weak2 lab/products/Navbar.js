import React, { Component } from 'react';
import Shoes from './Shoes';
import Clothing from './Clothing';
import Beauty from './Beauty';

import {
    BrowserRouter as Router,
    Route,
    NavLink 
} from 'react-router-dom';

class Navbar extends Component {

    render() {
        return (
            <Router>
                    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
                        <NavLink className="navbar-brand" to="/home" activeClassName="active">Products</NavLink>                        
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarColor01">
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/shoes" activeClassName="active">Shoes</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/clothing" activeClassName="active">Clothing</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/beauty" activeClassName="active">Beauty</NavLink>
                                </li>
                            </ul>
                        </div>
                    </nav>
                    <Route exact path="/shoes" component={Shoes} />
                    <Route exact path="/clothing" component={Clothing} />
                    <Route exact path="/beauty" component={Beauty} />
            </Router>
        );
    }
}

export default Navbar;