import React, { Component } from 'react'

class Beauty extends Component {

    render() {
        return (
            <div className="container">
                <div className="jumbotron py-3 mt-2">
                    <p className="h4 text-center mb-0">Beauty Component</p>
                </div>
                <h5>Welcome to buy something in Beauty component</h5>
                <h6>Happy Shopping!!!!!</h6>
            </div>
        );
    }
}
export default Beauty;