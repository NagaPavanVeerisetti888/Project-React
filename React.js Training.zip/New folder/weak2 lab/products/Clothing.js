import React, { Component } from 'react'

class Clothing extends Component {

    render() {
        return (
            <div className="container">
                <div className="jumbotron py-3 mt-2">
                    <p className="h4 text-center mb-0">Clothing Component</p>
                </div>
                <h5>Welcome to buy something in Clothing component</h5>
                <h6>Happy Shopping!!!!!</h6>
            </div>
        );
    }
}
export default Clothing;