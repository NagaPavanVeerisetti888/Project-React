import React, { Component } from 'react'

import Navbar from './Navbar';

class Text extends Component {

  
  render() {
    return (
      <Navbar/>
    );
  }
}
export default Text;