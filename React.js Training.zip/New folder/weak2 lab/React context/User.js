import React, { Component } from 'react';
import { MyContext } from './App';

class User extends Component {

    render() {
        return (
            <MyContext.Consumer>
                {(context) => (
                    <div>
                        <div className="jumbotron py-3 mb-4 mt-3 h4">
                            User Details
                        </div>
                        <ul>
                            <li><span className="font-weight-bold">Id: </span> {context.state.id}</li>
                            <li><span className="font-weight-bold">Name: </span> {context.state.name}</li>
                            <li><span className="font-weight-bold">Email: </span>{context.state.email}</li>
                        </ul>
                    </div>
                )}
            </MyContext.Consumer>
        );
    }
}

export default User;