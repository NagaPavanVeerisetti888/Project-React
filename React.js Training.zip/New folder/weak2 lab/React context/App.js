import React, { Component } from 'react';
import User from './User';

export const MyContext = React.createContext();

class App extends Component {

  constructor(){
    super()
    this.state = {
      id:1,
      name:"Jyothsna",
      email:"jyothsna@hcl.com"
    }
  }

  render() {
    return (
      <MyContext.Provider value={{
        state: this.state,
        
      }}>
        <div className="container">
          <User />
        </div>
      </MyContext.Provider>
    );
  }
}

export default App;