import React, { Component } from 'react'
import axios from 'axios';

class Text extends Component {

  componentDidMount() {
    axios.get('https://jsonplaceholder.typicode.com/todos')
      .then(res => {
        this.setState({
          todo: res.data,

        })
      })
  }

  constructor() {
    super()
    this.state = {
      todo: []

    }
  }

  getTodoList() {
    var todos = this.state.todo.map(
      (todo, index) =>
        <li>
          <p><span className="font-weight-bold">Title: </span> {todo.title}</p>
          <p><span className="font-weight-bold">Id: </span>{todo.id}</p>
          <p><span className="font-weight-bold">Status: </span> {(todo.completed) ? <p>Yes</p> : <p>No</p>}</p>

        </li>
    )
    return todos
  }
  render() {
    return (
      <div className="container">
        <div className="jumbotron py-3 my-4">
          <p className="display-4 text-center mb-0">Todo List</p>
        </div>
        <ul>
          {this.getTodoList()}
        </ul>
      </div>
    );
  }
}
export default Text;