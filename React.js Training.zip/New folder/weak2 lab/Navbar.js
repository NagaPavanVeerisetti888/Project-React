import React, { Component } from 'react';

class User extends Component {

    render() {
        return (
            <div className="container">
                <div className="jumbotron py-3">
                    <p className="h4 text-center mb-0">User Component</p>

                </div>
                <h4> Welcome To User Data</h4>
                <input type="text" placeholder="email" />
                <input type="text" placeholder="password" />
                <button type="Submit" className="btn btn-success">Submit</button>
            </div>
        );
    }
}

export default User;