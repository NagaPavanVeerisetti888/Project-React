import React, { Component } from 'react';
import Color from './Color';


class App extends Component {

  render() {
    return (
      <div className="container">
        <div className="jumbotron py-3 my-4">
          <p className="display-4 text-center mb-0">Getting Color!</p>
        </div>

        <Color colorName="Red" />


      </div>
    );
  }
}

export default App;