class User {

    userId

    userName

    userEmail

    userPassword

    userMobile
    
    userAddress

    userPincode

    



    constructor() {

        this.userId = 0

        this.userName = ""

        this.userEmail = ""

        this.userPassword = ""

        this.userMobile = ""

        this.userAddress = ""

        this.userPincode = ""

    }



}

export default User