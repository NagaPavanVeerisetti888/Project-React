import React, { Component } from 'react';



class cart extends Component {


    render() {

        return (

            <div className="container">

                <div className="jumbotron py-3">

                    <p className="h4 text-center">Cart</p>


                </div>

            </div>

        );

    }

}



export default cart;